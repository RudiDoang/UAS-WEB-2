<?php
if( empty( $_SESSION['id_user'] ) ){

	$_SESSION['err'] = '<strong>ERROR!</strong> Anda harus login terlebih dahulu.';
	header('Location: ./');
	die();
} else {

	if( isset( $_REQUEST['submit'] )){

		$id_jns = $_REQUEST['id_jns'];
		$jml_tr = $_REQUEST['jumlah_transaksi'];
		$jml_dana = $_REQUEST['jumlah_dana'];
		$nama = $_REQUEST['nama'];
		$nohp = $_REQUEST['no_hp'];
		$email = $_REQUEST['email'];
		$id_user = $_SESSION['id_user'];

		$sql = mysqli_query($koneksi, "INSERT INTO bantuan_sosial(id_jns, nama, jumlah_transaksi, jumlah_dana, no_hp, email, tanggal, id_user) 
		VALUES('$id_jns', '$nama', '$jml_tr', '$jml_dana', '$nohp', '$email', NOW(), '$id_user')");

		if($sql == true){
			header('Location: ./admin.php?hlm=transaksi');
			die();
		} else {
			echo 'ERROR! Periksa penulisan querynya.';
		}
	} else {
?>
<h2>Tambah Transaksi Baru</h2>
<hr>
<form method="post" action="" class="form-horizontal" role="form">
	<div class="form-group">
		
	</div>
	<div class="form-group">
		<label for="jenis" class="col-sm-2 control-label">Jenis Alokasi</label>
		<div class="col-sm-3">
			<select name="id_jns" class="form-control" id="jenis" required>
				<option value="" >--- Pilih Jenis Alokasi ---</option>
			<?php

				$q = mysqli_query($koneksi, "SELECT * FROM jenis_alokasi");
				while($data = mysqli_fetch_array($q)){
					echo '<option value="'.$data['id_jns'].'">'.$data['alokasi'].'</option>';
				}

			?>
			</select>
		</div>
	</div>
	<div class="form-group">
		<label for="bayar" class="col-sm-2 control-label">Jumlah Transaksi</label>
		<div class="col-sm-3">
			<input type="number" class="form-control" id="jumlah_transaksi" name="jumlah_transaksi" placeholder="Jumlah Transaksi" required>
		</div>
	</div>
	<div class="form-group">
		<label for="kembali" class="col-sm-2 control-label">Jumlah Dana</label>
		<div class="col-sm-3">
			<input type="number" class="form-control" id="jumlah_dana" name="jumlah_dana" placeholder="Jumlah Dana" required>
		</div>
	</div>
	<div class="form-group">
		<label for="total" class="col-sm-2 control-label">Nama Lengkap</label>
		<div class="col-sm-3">
			<input type="text" class="form-control" id="nama" name="nama" placeholder="Nama Lengkap" required>
		</div>
	</div>
	<div class="form-group">
		<label for="nama" class="col-sm-2 control-label">No Handphone</label>
		<div class="col-sm-4">
			<input type="text" class="form-control" id="no_hp" name="no_hp" placeholder="Nomor Handphone" required>
		</div>
	</div>
	<div class="form-group">
		<label for="nama" class="col-sm-2 control-label">Email</label>
		<div class="col-sm-4">
			<input type="text" class="form-control" id="email" name="email" placeholder="Email" required>
		</div>
	</div>
	<div class="form-group">
		<div class="col-sm-offset-2 col-sm-10">
			<button type="submit" name="submit" class="btn btn-success">Simpan</button>
			<a href="./admin.php?hlm=transaksi" class="btn btn-danger">Batal</a>
		</div>
	</div>
</form>
<?php
	}
}
?>

